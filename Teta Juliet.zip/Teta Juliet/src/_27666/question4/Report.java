package _27666.question4;

import java.time.LocalDate;
import java.util.ArrayList;

    public final class Report {
        private LocalDate reportDate;
        private String summary;
        private ArrayList<Invoice> invoices = new ArrayList<>();

        public Report() {
            this.reportDate = LocalDate.now();
        }

        public void addInvoice(Invoice invoice) {
            invoices.add(invoice);
        }

        public double calculateTotal() {
            double total = 0;
            for (Invoice i : invoices) {
                total += i.getInvoiceAmount();
            }
            return total;
        }

        public void generateReport(String studentID) {
            System.out.println("\n=== PROCUREMENT REPORT === " + studentID);
            System.out.println("Report Date: " + reportDate + " " + studentID);
            System.out.println("Total Invoices: " + invoices.size() + " " + studentID);
            System.out.println("Total Amount: " + calculateTotal() + " " + studentID);
            System.out.println("===========================" + studentID);
        }
    }


