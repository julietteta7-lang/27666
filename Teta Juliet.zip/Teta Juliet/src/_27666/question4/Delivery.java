package _27666.question4;
import java.time.LocalDate;

    public class Delivery extends PurchaseOrder {
        private LocalDate deliveryDate;
        private String deliveredBy;

        public Delivery(int id, String orgName, String address, String email,
                        String deptName, String deptCode,
                        String supplierName, String TIN, String contact,
                        String productName, double unitPrice, int quantity,
                        String poNumber, double totalAmount,
                        String deliveredBy) {

            super(id, orgName, address, email, deptName, deptCode, supplierName, TIN, contact,
                    productName, unitPrice, quantity, poNumber, totalAmount);

            this.deliveryDate = LocalDate.now();
            this.deliveredBy = deliveredBy;
        }
    }


