package _27666.question4;
import java.util.Scanner;

    public class Main {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            String studentID = "(27666)";

            System.out.print("Enter Organization Name: ");
            String orgName = sc.nextLine();

            System.out.print("Enter Address: ");
            String addr = sc.nextLine();

            System.out.print("Enter Contact Email: ");
            String email = sc.nextLine();

            System.out.print("Enter Department Name: ");
            String deptName = sc.nextLine();

            System.out.print("Enter Dept Code: ");
            String deptCode = sc.nextLine();

            System.out.print("Enter Supplier Name: ");
            String sName = sc.nextLine();

            System.out.print("Enter Supplier TIN (9 digits): ");
            String tin = sc.nextLine();

            System.out.print("Enter Supplier Phone (10 digits): ");
            String phone = sc.nextLine();

            System.out.print("Enter Product Name: ");
            String product = sc.nextLine();

            System.out.print("Enter Unit Price: ");
            double price = sc.nextDouble();

            System.out.print("Enter Quantity: ");
            int qty = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter PO Number: ");
            String po = sc.nextLine();

            double totalAmount = price * qty;

            Invoice invoice = new Invoice(
                    1, orgName, addr, email, deptName, deptCode,
                    sName, tin, phone, product, price, qty,
                    po, totalAmount, "John", "Inspector", "Passed", "OK", "INV001", totalAmount
            );

            Report report = new Report();
            report.addInvoice(invoice);
            report.generateReport(studentID);

            sc.close();
        }
    }


