package _27666.question4;
    public class Organization extends Entity {
        private String orgName;
        private String address;
        private String contactEmail;

        public Organization(int id, String orgName, String address, String email) {
            super(id);
            if (!email.contains("@")) throw new IllegalArgumentException("Invalid email");
            this.orgName = orgName;
            this.address = address;
            this.contactEmail = email;
        }
    }


