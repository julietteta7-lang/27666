package _27666.question4;
    public class Product extends Supplier {
        private String productName;
        private double unitPrice;
        private int quantity;

        public Product(int id, String orgName, String address, String email,
                       String deptName, String deptCode,
                       String supplierName, String TIN, String contact,
                       String productName, double unitPrice, int quantity) {

            super(id, orgName, address, email, deptName, deptCode, supplierName, TIN, contact);

            if (unitPrice <= 0) throw new IllegalArgumentException("Unit price must be > 0");
            if (quantity < 0) throw new IllegalArgumentException("Quantity must be ≥ 0");

            this.productName = productName;
            this.unitPrice = unitPrice;
            this.quantity = quantity;
        }
    }


