package _27666.question4;
import java.time.LocalDate;

    public class PurchaseOrder extends Product {
        private String poNumber;
        private LocalDate orderDate;
        private double totalAmount;

        public PurchaseOrder(int id, String orgName, String address, String email,
                             String deptName, String deptCode,
                             String supplierName, String TIN, String contact,
                             String productName, double unitPrice, int quantity,
                             String poNumber, double totalAmount) {

            super(id, orgName, address, email, deptName, deptCode, supplierName, TIN, contact,
                    productName, unitPrice, quantity);

            if (totalAmount <= 0) throw new IllegalArgumentException("Total must be > 0");

            this.poNumber = poNumber;
            this.orderDate = LocalDate.now();
            this.totalAmount = totalAmount;
        }
    }


