package _27666.question4;
    public class Invoice extends Inspection {
        private String invoiceNo;
        private double invoiceAmount;

        public Invoice(int id, String orgName, String address, String email,
                       String deptName, String deptCode,
                       String supplierName, String TIN, String contact,
                       String productName, double unitPrice, int quantity,
                       String poNumber, double totalAmount,
                       String deliveredBy,
                       String inspectorName, String status, String remarks,
                       String invoiceNo, double invoiceAmount) {

            super(id, orgName, address, email, deptName, deptCode,
                    supplierName, TIN, contact,
                    productName, unitPrice, quantity,
                    poNumber, totalAmount, deliveredBy,
                    inspectorName, status, remarks);

            if (invoiceAmount <= 0)
                throw new IllegalArgumentException("Invoice amount must be > 0");

            this.invoiceNo = invoiceNo;
            this.invoiceAmount = invoiceAmount;
        }

        public double getInvoiceAmount() {
            return invoiceAmount;
        }
    }


