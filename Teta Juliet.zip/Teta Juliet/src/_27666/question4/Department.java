package _27666.question4;
    public class Department extends Organization {
        private String deptName;
        private String deptCode;

        public Department(int id, String orgName, String address, String email,
                          String deptName, String deptCode) {
            super(id, orgName, address, email);

            if (deptCode.length() < 3)
                throw new IllegalArgumentException("Dept code must be ≥ 3 chars");

            this.deptName = deptName;
            this.deptCode = deptCode;
        }
    }

