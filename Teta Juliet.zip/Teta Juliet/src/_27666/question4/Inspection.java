package _27666.question4;
    public class Inspection extends Delivery {
        private String inspectorName;
        private String status; // Passed or Failed
        private String remarks;

        public Inspection(int id, String orgName, String address, String email,
                          String deptName, String deptCode,
                          String supplierName, String TIN, String contact,
                          String productName, double unitPrice, int quantity,
                          String poNumber, double totalAmount,
                          String deliveredBy,
                          String inspectorName, String status, String remarks) {

            super(id, orgName, address, email, deptName, deptCode,
                    supplierName, TIN, contact,
                    productName, unitPrice, quantity,
                    poNumber, totalAmount, deliveredBy);

            if (!status.equals("Passed") && !status.equals("Failed"))
                throw new IllegalArgumentException("Status must be Passed/Failed");

            this.inspectorName = inspectorName;
            this.status = status;
            this.remarks = remarks;
        }
    }
