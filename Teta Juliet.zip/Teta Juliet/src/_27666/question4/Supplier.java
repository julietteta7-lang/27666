package _27666.question4;
    public class Supplier extends Department {
        private String supplierName;
        private String supplierTIN;
        private String contact;

        public Supplier(int id, String orgName, String address, String email,
                        String deptName, String deptCode,
                        String supplierName, String TIN, String contact) {

            super(id, orgName, address, email, deptName, deptCode);

            if (TIN.length() != 9) throw new IllegalArgumentException("TIN must be 9 digits");
            if (contact.length() != 10) throw new IllegalArgumentException("Phone must be 10 digits");

            this.supplierName = supplierName;
            this.supplierTIN = TIN;
            this.contact = contact;
        }
    }


