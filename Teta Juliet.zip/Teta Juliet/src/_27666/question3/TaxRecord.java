package _27666.question3;
    public final class TaxRecord extends Entity {

        private String receiptNo;
        private double totalTax;

        public TaxRecord(int id, String receiptNo) {
            super(id);
            this.receiptNo = receiptNo;
        }

        public double computeTax(double salary, double rate, double credits) {
            this.totalTax = (salary * rate) - credits;
            if (totalTax < 0) totalTax = 0;
            return totalTax;
        }

        public String getReceiptNo() { return receiptNo; }
        public double getTotalTax() { return totalTax; }
    }


