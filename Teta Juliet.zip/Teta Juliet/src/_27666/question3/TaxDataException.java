package _27666.question3;

public class TaxDataException extends RuntimeException {
    public TaxDataException(String message) {
        super(message);
    }
}
