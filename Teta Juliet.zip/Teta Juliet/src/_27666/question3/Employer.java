package _27666.question3;
    public class Employer extends Entity {

        private String employerName;
        private String employerTIN;
        private String contact;

        public Employer(int id, String name, String tin, String contact) {
            super(id);

            if (tin.length() != 9)
                throw new TaxDataException("Employer TIN must be 9 digits");
            if (contact.length() != 10)
                throw new TaxDataException("Phone number must be 10 digits");

            this.employerName = name;
            this.employerTIN = tin;
            this.contact = contact;
        }

        public String getEmployerName() { return employerName; }
        public String getEmployerTIN() { return employerTIN; }
        public String getContact() { return contact; }
    }

