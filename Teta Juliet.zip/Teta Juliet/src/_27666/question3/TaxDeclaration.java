package _27666.question3;
    public class TaxDeclaration extends Entity {

        private String declarationMonth;
        private double totalIncome;

        public TaxDeclaration(int id, String month, double income) {
            super(id);

            if (income < 0)
                throw new TaxDataException("Income must be >= 0");

            this.declarationMonth = month;
            this.totalIncome = income;
        }

        public String getDeclarationMonth() { return declarationMonth; }
        public double getTotalIncome() { return totalIncome; }
    }

