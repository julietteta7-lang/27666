package _27666.question3;
import java.time.LocalDate;

    public class TaxAssessment extends Entity {

        private LocalDate assessmentDate;
        private double assessedTax;

        public TaxAssessment(int id, double assessedTax) {
            super(id);

            if (assessedTax < 0)
                throw new TaxDataException("Assessed tax must be >= 0");

            this.assessmentDate = LocalDate.now();
            this.assessedTax = assessedTax;
        }

        public LocalDate getAssessmentDate() { return assessmentDate; }
        public double getAssessedTax() { return assessedTax; }
    }


