package _27666.question3;
    public class TaxCategory extends Entity {

        private String categoryName;
        private double rate; // rate > 0
        private String code; // ≥3 chars

        public TaxCategory(int id, String categoryName, double rate, String code) {
            super(id);

            if (rate <= 0) throw new TaxDataException("Rate must be > 0");
            if (code.length() < 3) throw new TaxDataException("Category code must be at least 3 characters");

            this.categoryName = categoryName;
            this.rate = rate;
            this.code = code;
        }

        public String getCategoryName() { return categoryName; }
        public double getRate() { return rate; }
        public String getCode() { return code; }
    }

