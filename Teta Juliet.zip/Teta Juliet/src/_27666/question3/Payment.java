package _27666.question3;
import java.time.LocalDate;

    public class Payment extends Entity {

        private LocalDate paymentDate;
        private double paymentAmount;

        public Payment(int id, double amount) {
            super(id);

            if (amount <= 0)
                throw new TaxDataException("Payment amount must be > 0");

            this.paymentAmount = amount;
            this.paymentDate = LocalDate.now();
        }

        public LocalDate getPaymentDate() { return paymentDate; }
        public double getPaymentAmount() { return paymentAmount; }
    }

