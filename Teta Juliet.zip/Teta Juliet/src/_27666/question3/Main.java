package _27666.question3;
import java.util.Scanner;

    public class Main {

        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);
            String studentID = "(27666)";

            System.out.println("=== TAX ADMINISTRATION SYSTEM ===");

            // TAX AUTHORITY
            System.out.print("Enter Tax Authority Name: ");
            String tName = sc.nextLine();

            System.out.print("Enter Region: ");
            String region = sc.nextLine();

            System.out.print("Enter Authority Email: ");
            String email = sc.nextLine();

            TaxAuthority authority = new TaxAuthority(1, tName, region, email);

            // CATEGORY
            System.out.print("Enter Tax Category Name: ");
            String cName = sc.nextLine();

            System.out.print("Enter Tax Rate (e.g. 0.2 for 20%): ");
            double rate = sc.nextDouble();
            sc.nextLine();

            System.out.print("Enter Category Code (min 3 chars): ");
            String cCode = sc.nextLine();

            TaxCategory category = new TaxCategory(2, cName, rate, cCode);

            // TAXPAYER
            System.out.print("Enter Taxpayer Name: ");
            String tpName = sc.nextLine();

            System.out.print("Enter Taxpayer TIN (9 digits): ");
            String tin = sc.nextLine();

            System.out.print("Enter Address: ");
            String address = sc.nextLine();

            Taxpayer taxpayer = new Taxpayer(3, tin, tpName, address);

            // EMPLOYEE
            System.out.print("Enter Employee Name: ");
            String eName = sc.nextLine();

            System.out.print("Enter Salary (>0): ");
            double salary = sc.nextDouble();
            sc.nextLine();

            System.out.print("Enter Employee TIN (9 digits): ");
            String etin = sc.nextLine();

            Employee employee = new Employee(4, eName, salary, etin);

            // DECLARATION
            System.out.print("Enter Declaration Month: ");
            String month = sc.nextLine();

            System.out.print("Enter Total Income: ");
            double income = sc.nextDouble();

            TaxDeclaration declaration = new TaxDeclaration(5, month, income);

            // ASSESSMENT
            TaxAssessment assessment = new TaxAssessment(6, salary * rate);

            // PAYMENT
            System.out.print("Enter Payment Amount: ");
            double pay = sc.nextDouble();

            Payment payment = new Payment(7, pay);

            // TAX RECORD
            sc.nextLine();
            System.out.print("Enter Receipt No: ");
            String rno = sc.nextLine();

            TaxRecord record = new TaxRecord(8, rno);
            double computedTax = record.computeTax(salary, rate, 0); // credits = 0

            // FINAL OUTPUT WITH STUDENT ID
            System.out.println("\n--- TAX RECORD --- " + studentID);
            System.out.println("Receipt No: " + record.getReceiptNo());
            System.out.println("Employee: " + employee.getEmployeeName());
            System.out.println("Salary: " + employee.getSalary());
            System.out.println("Rate: " + category.getRate());
            System.out.println("Computed Tax: " + computedTax);
            System.out.println("Assessed Tax: " + assessment.getAssessedTax());
            System.out.println("Payment Amount: " + payment.getPaymentAmount());
            System.out.println("---------------------------------- " + studentID);

            sc.close();
        }
    }

