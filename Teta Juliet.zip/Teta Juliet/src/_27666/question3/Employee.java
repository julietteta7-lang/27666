package _27666.question3;
public class Employee extends Entity {

        private String employeeName;
        private double salary;
        private String employeeTIN;

        public Employee(int id, String name, double salary, String tin) {
            super(id);

            if (salary <= 0)
                throw new TaxDataException("Salary must be > 0");
            if (tin.length() != 9)
                throw new TaxDataException("Employee TIN must be 9 digits");

            this.employeeName = name;
            this.salary = salary;
            this.employeeTIN = tin;
        }

        public String getEmployeeName() { return employeeName; }
        public double getSalary() { return salary; }
        public String getEmployeeTIN() { return employeeTIN; }
    }

