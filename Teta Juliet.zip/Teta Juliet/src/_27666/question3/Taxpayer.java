package _27666.question3;
public class Taxpayer extends Entity {

        private String tin;  // 9 digits
        private String taxpayerName;
        private String address;

        public Taxpayer(int id, String tin, String name, String address) {
            super(id);

            if (tin.length() != 9)
                throw new TaxDataException("TIN must be exactly 9 digits");
            if (name.isEmpty() || address.isEmpty())
                throw new TaxDataException("Fields cannot be empty");

            this.tin = tin;
            this.taxpayerName = name;
            this.address = address;
        }

        public String getTin() { return tin; }
        public String getTaxpayerName() { return taxpayerName; }
        public String getAddress() { return address; }
    }


