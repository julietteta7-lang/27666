package _27666.question6;
    import java.time.LocalDate;

    public class PayrollPeriod {
        private int month;
        private int year;
        private LocalDate startDate;
        private LocalDate endDate;

        public PayrollPeriod(int month, int year, LocalDate startDate, LocalDate endDate) {
            if (month < 1 || month > 12) throw new IllegalArgumentException("Invalid month");
            if (year < 2000) throw new IllegalArgumentException("Year must be >= 2000");
            if (startDate == null || endDate == null) throw new IllegalArgumentException("Dates cannot be null");
            this.month = month;
            this.year = year;
            this.startDate = startDate;
            this.endDate = endDate;
        }

        public int getMonth() { return month; }
        public int getYear() { return year; }
        public LocalDate getStartDate() { return startDate; }
        public LocalDate getEndDate() { return endDate; }
    }


