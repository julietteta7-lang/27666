package _27666.question6;
    public class Department extends Organization {
        private String deptName;
        private String deptCode;
        private String managerName;

        public Department(int id, String orgName, String orgCode, String rssbNumber, String contactEmail,
                          String deptName, String deptCode, String managerName) {
            super(id, orgName, orgCode, rssbNumber, contactEmail);
            if (deptName.isEmpty() || managerName.isEmpty() || deptCode.length() < 3)
                throw new IllegalArgumentException("Invalid department details");
            this.deptName = deptName;
            this.deptCode = deptCode;
            this.managerName = managerName;
        }

        public String getDeptName() { return deptName; }
        public String getDeptCode() { return deptCode; }
        public String getManagerName() { return managerName; }
    }

