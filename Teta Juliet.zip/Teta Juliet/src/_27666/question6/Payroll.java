package _27666.question6;
    public class Payroll {
        private double grossSalary;
        private double totalDeductions;
        private double netSalary;

        public Payroll(SalaryStructure salary, Allowance allowance, Deduction deduction) {
            this.grossSalary = salary.getBasicPay() + salary.getHousingAllowance() + salary.getTransportAllowance() + allowance.totalAllowance();
            this.totalDeductions = deduction.totalDeductions();
            this.netSalary = grossSalary - totalDeductions;
        }

        public double getGrossSalary() { return grossSalary; }
        public double getTotalDeductions() { return totalDeductions; }
        public double getNetSalary() { return netSalary; }
    }

