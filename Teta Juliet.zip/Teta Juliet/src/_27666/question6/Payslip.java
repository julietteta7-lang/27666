package _27666.question6;
    import java.time.LocalDate;

    public final class Payslip extends Payroll {
        private String payslipNumber;
        private LocalDate issueDate;

        public Payslip(String payslipNumber, SalaryStructure salary, Allowance allowance, Deduction deduction) {
            super(salary, allowance, deduction);
            this.payslipNumber = payslipNumber;
            this.issueDate = LocalDate.now();
        }

        public void generatePayslip(String studentID) {
            System.out.println("STUDENT ID: " + studentID);
            System.out.println("Payslip Number: " + payslipNumber);
            System.out.println("Issue Date: " + issueDate);
            System.out.printf("Gross Salary: %.2f\n", getGrossSalary());
            System.out.printf("Total Deductions: %.2f\n", getTotalDeductions());
            System.out.printf("Net Salary: %.2f\n", getNetSalary());
            System.out.println("-----------------------------------");
        }
    }

