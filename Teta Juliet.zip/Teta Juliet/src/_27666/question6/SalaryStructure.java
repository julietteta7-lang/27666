package _27666.question6;
    public class SalaryStructure {
        private double basicPay;
        private double transportAllowance;
        private double housingAllowance;

        public SalaryStructure(double basicPay, double transportAllowance, double housingAllowance) {
            if (basicPay < 0 || transportAllowance < 0 || housingAllowance < 0)
                throw new IllegalArgumentException("Salaries and allowances must be >= 0");
            this.basicPay = basicPay;
            this.transportAllowance = transportAllowance;
            this.housingAllowance = housingAllowance;
        }

        public double getBasicPay() { return basicPay; }
        public double getTransportAllowance() { return transportAllowance; }
        public double getHousingAllowance() { return housingAllowance; }
    }


