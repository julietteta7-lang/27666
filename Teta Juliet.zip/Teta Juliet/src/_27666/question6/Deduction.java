package _27666.question6;
    public class Deduction {
        private double rssbContribution;
        private double payeTax;
        private double loanDeduction;

        public Deduction(double basicPay, double payeTax, double loanDeduction) {
            if (basicPay < 0 || payeTax < 0 || loanDeduction < 0) throw new IllegalArgumentException("Deductions must be >= 0");
            this.rssbContribution = basicPay * 0.05; // 5% of basicPay
            this.payeTax = payeTax;
            this.loanDeduction = loanDeduction;
        }

        public double getRssbContribution() { return rssbContribution; }
        public double getPayeTax() { return payeTax; }
        public double getLoanDeduction() { return loanDeduction; }

        public double totalDeductions() { return rssbContribution + payeTax + loanDeduction; }
    }

