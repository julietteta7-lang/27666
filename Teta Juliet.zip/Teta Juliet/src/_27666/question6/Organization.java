package _27666.question6;
    import java.util.regex.Pattern;

    public class Organization extends Entity {
        private String orgName;
        private String orgCode;
        private String rssbNumber;
        private String contactEmail;

        public Organization(int id, String orgName, String orgCode, String rssbNumber, String contactEmail) {
            super(id, java.time.LocalDate.now(), java.time.LocalDate.now());
            if (orgName.isEmpty() || orgCode.length() < 3) throw new IllegalArgumentException("Invalid organization details");
            if (!rssbNumber.matches("\\d{8}")) throw new IllegalArgumentException("RSSB Number must be 8 digits");
            if (!Pattern.matches("^\\S+@\\S+\\.\\S+$", contactEmail)) throw new IllegalArgumentException("Invalid email");
            this.orgName = orgName;
            this.orgCode = orgCode;
            this.rssbNumber = rssbNumber;
            this.contactEmail = contactEmail;
        }

        public String getOrgName() { return orgName; }
        public String getOrgCode() { return orgCode; }
        public String getRssbNumber() { return rssbNumber; }
        public String getContactEmail() { return contactEmail; }
    }


