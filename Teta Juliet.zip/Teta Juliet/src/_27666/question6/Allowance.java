package _27666.question6;
    public class Allowance {
        private double overtimeHours;
        private double overtimeRate;
        private double bonus;

        public Allowance(double overtimeHours, double overtimeRate, double bonus) {
            if (overtimeHours < 0 || overtimeRate < 0 || bonus < 0) throw new IllegalArgumentException("Invalid allowance values");
            this.overtimeHours = overtimeHours;
            this.overtimeRate = overtimeRate;
            this.bonus = bonus;
        }

        public double getOvertimeAmount() { return overtimeHours * overtimeRate; }
        public double getBonus() { return bonus; }
        public double totalAllowance() { return getOvertimeAmount() + bonus; }
    }

