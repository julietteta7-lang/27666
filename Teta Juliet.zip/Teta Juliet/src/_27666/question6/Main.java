package _27666.question6;
    import java.time.LocalDate;
import java.util.Scanner;

    public class Main {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);

            // Example input
            System.out.print("Enter Basic Pay: ");
            double basic = sc.nextDouble();
            System.out.print("Enter Transport Allowance: ");
            double transport = sc.nextDouble();
            System.out.print("Enter Housing Allowance: ");
            double housing = sc.nextDouble();

            System.out.print("Enter Overtime Hours: ");
            double hours = sc.nextDouble();
            System.out.print("Enter Overtime Rate: ");
            double rate = sc.nextDouble();
            System.out.print("Enter Bonus: ");
            double bonus = sc.nextDouble();

            System.out.print("Enter PAYE Tax: ");
            double paye = sc.nextDouble();
            System.out.print("Enter Loan Deduction: ");
            double loan = sc.nextDouble();

            SalaryStructure salary = new SalaryStructure(basic, transport, housing);
            Allowance allowance = new Allowance(hours, rate, bonus);
            Deduction deduction = new Deduction(basic, paye, loan);

            Payslip payslip = new Payslip("PSL001", salary, allowance, deduction);

            payslip.generatePayslip("STU12345");
        }
    }


