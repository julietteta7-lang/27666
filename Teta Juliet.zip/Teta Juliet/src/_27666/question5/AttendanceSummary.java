package _27666.question5;
import java.time.LocalDate;
import java.util.ArrayList;

    public final class AttendanceSummary {
        private LocalDate reportDate = LocalDate.now();
        private int totalPresent = 0;
        private int totalAbsent = 0;

        private ArrayList<AttendanceRecord> records = new ArrayList<>();

        public void addRecord(AttendanceRecord record) {
            if (record.getStatus().equals("Present"))
                totalPresent++;
            else
                totalAbsent++;

            records.add(record);
        }

        public double generateSummary(String studentID) {
            int totalSessions = totalPresent + totalAbsent;
            double percentage = ((double) totalPresent / totalSessions) * 100;

            System.out.println("\n=== ATTENDANCE SUMMARY === " + studentID);
            System.out.println("Report Date: " + reportDate + " " + studentID);
            System.out.println("Total Present: " + totalPresent + " " + studentID);
            System.out.println("Total Absent: " + totalAbsent + " " + studentID);
            System.out.println("Attendance Percentage: " + percentage + "% " + studentID);
            System.out.println("===========================" + studentID);

            return percentage;
        }
    }


