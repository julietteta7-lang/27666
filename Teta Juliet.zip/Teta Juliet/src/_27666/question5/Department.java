package _27666.question5;
public class Department extends Institution {
        private String departmentName;
        private String departmentHead;

        public Department(int id, String institutionName, String code, String address,
                          String departmentName, String departmentHead) {
            super(id, institutionName, code, address);

            if (departmentName.isEmpty() || departmentHead.isEmpty())
                throw new IllegalArgumentException("Fields cannot be empty");

            this.departmentName = departmentName;
            this.departmentHead = departmentHead;
        }
    }


