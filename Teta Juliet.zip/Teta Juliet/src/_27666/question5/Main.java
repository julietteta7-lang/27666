package _27666.question5;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Student Name: ");
        String sName = sc.nextLine();

        System.out.print("Enter Student ID: ");
        String sID = sc.nextLine();

        System.out.print("Enter Age: ");
        int age = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Session Topic: ");
        String topic = sc.nextLine();

        System.out.print("Enter Status (Present/Absent): ");
        String status = sc.nextLine();

        AttendanceRecord record = new AttendanceRecord(
                1, "UR", "UR1", "Kigali", "ICT", "Dr.John",
                "OOP", "OOP101", 3, "Alice", "alice@ur.ac.rw", "0780000000",
                sName, sID, age, topic, 1, status
        );

        AttendanceSummary summary = new AttendanceSummary();
        summary.addRecord(record);

        summary.generateSummary("(27666)");

        sc.close();
    }
}
