package _27666.question5;
import java.time.LocalDate;

    public class ClassSession extends Student {
        private LocalDate sessionDate;
        private String topic;

        public ClassSession(int id, String institutionName, String code, String address,
                            String departmentName, String departmentHead,
                            String courseName, String courseCode, int credits,
                            String instructorName, String email, String phone,
                            String studentName, String studentID, int age,
                            String topic) {
            super(id, institutionName, code, address, departmentName, departmentHead,
                    courseName, courseCode, credits, instructorName, email, phone,
                    studentName, studentID, age);

            if (topic.isEmpty())
                throw new IllegalArgumentException("Topic cannot be empty");

            this.sessionDate = LocalDate.now();
            this.topic = topic;
        }

        public LocalDate getSessionDate() {
            return sessionDate;
        }
    }


