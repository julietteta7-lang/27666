package _27666.question5;
import java.time.LocalDate;

    public class LeaveRequest extends AttendanceRecord {
        private LocalDate requestDate;
        private String reason;
        private boolean approved;

        public LeaveRequest(int id, String institutionName, String code, String address,
                            String departmentName, String departmentHead,
                            String courseName, String courseCode, int credits,
                            String instructorName, String email, String phone,
                            String studentName, String studentID, int age,
                            String topic, int sessionID, String status,
                            String reason, boolean approved) {
            super(id, institutionName, code, address, departmentName, departmentHead,
                    courseName, courseCode, credits, instructorName, email, phone,
                    studentName, studentID, age, topic, sessionID, status);

            if (reason.isEmpty()) throw new IllegalArgumentException("Reason required");

            this.requestDate = LocalDate.now();
            this.reason = reason;
            this.approved = approved;
        }
    }


