package _27666.question5;
    public class Institution extends Entity {
        private String institutionName;
        private String code;
        private String address;

        public Institution(int id, String institutionName, String code, String address) {
            super(id);
            if (code.length() < 3) throw new IllegalArgumentException("Code must be ≥ 3 characters");

            this.institutionName = institutionName;
            this.code = code;
            this.address = address;
        }
    }


