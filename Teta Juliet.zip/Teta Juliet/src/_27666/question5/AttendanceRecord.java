package _27666.question5;
    public class AttendanceRecord extends ClassSession {
        private String recordStudentID;
        private int sessionID;
        private String status;

        public AttendanceRecord(int id, String institutionName, String code, String address,
                                String departmentName, String departmentHead,
                                String courseName, String courseCode, int credits,
                                String instructorName, String email, String phone,
                                String studentName, String studentID, int age,
                                String topic, int sessionID, String status) {
            super(id, institutionName, code, address, departmentName, departmentHead,
                    courseName, courseCode, credits, instructorName, email, phone,
                    studentName, studentID, age, topic);

            if (!status.equals("Present") && !status.equals("Absent"))
                throw new IllegalArgumentException("Status must be Present or Absent");

            this.recordStudentID = studentID;
            this.sessionID = sessionID;
            this.status = status;
        }

        public String getStatus() { return status; }
    }

