package _27666.question1;
import java.time.LocalDate;

    public class Entity {
        private int id;
        private LocalDate createdDate;
        private LocalDate updatedDate;

        public Entity(int id) {
            if (id <= 0) throw new IllegalArgumentException("ID must be greater than 0");
            this.id = id;
            this.createdDate = LocalDate.now();
            this.updatedDate = LocalDate.now();
        }

        public int getId() { return id; }
        public LocalDate getCreatedDate() { return createdDate; }
        public LocalDate getUpdatedDate() { return updatedDate; }

        public void updateDate() {
            this.updatedDate = LocalDate.now();
        }
    }

