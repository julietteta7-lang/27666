package _27666.question1;

import java.time.LocalDate;

    public final class StockReport extends Entity {
        private LocalDate reportDate;
        private String remarks;

        public StockReport(int id, String remarks) {
            super(id);
            this.remarks = remarks;
            this.reportDate = LocalDate.now();
        }

        public String generateReport(int totalItems, double totalValue, int sales, String studentID) {
            return "\n----- STOCK REPORT ----- " + studentID +
                    "\nReport Date: " + reportDate +
                    "\nRemarks: " + remarks +
                    "\nTotal Items: " + totalItems +
                    "\nTotal Stock Value: " + totalValue +
                    "\nTotal Sales: " + sales +
                    "\n------------------------------\n";
        }
    }


