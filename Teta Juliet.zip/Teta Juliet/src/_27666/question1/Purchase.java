package _27666.question1;
import java.time.LocalDate;

    public class Purchase extends Entity {
        private LocalDate purchaseDate;
        private int purchasedQuantity;
        private String supplierName;

        public Purchase(int id, int quantity, String supplierName) {
            super(id);

            if (quantity <= 0) throw new IllegalArgumentException("Quantity must be > 0");

            this.purchasedQuantity = quantity;
            this.supplierName = supplierName;
            this.purchaseDate = LocalDate.now();
        }

        public int getPurchasedQuantity() { return purchasedQuantity; }
        public String getSupplierName() { return supplierName; }
        public LocalDate getPurchaseDate() { return purchaseDate; }
    }
