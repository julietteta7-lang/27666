package _27666.question1;
    public class Category extends Entity {
        private String categoryName;
        private String categoryCode; // alphanumeric ≥3 chars

        public Category(int id, String categoryName, String categoryCode) {
            super(id);

            if (categoryCode.length() < 3)
                throw new IllegalArgumentException("Category code must be at least 3 characters");

            this.categoryName = categoryName;
            this.categoryCode = categoryCode;
        }

        public String getCategoryName() { return categoryName; }
        public String getCategoryCode() { return categoryCode; }
    }

