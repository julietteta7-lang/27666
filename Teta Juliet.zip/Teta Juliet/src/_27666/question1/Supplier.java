package _27666.question1;

    public class Supplier extends Entity {
        private String supplierName;
        private String supplierEmail;
        private String supplierPhone;

        public Supplier(int id, String name, String email, String phone) {
            super(id);

            if (!email.contains("@"))
                throw new IllegalArgumentException("Invalid email");

            if (phone.length() != 10)
                throw new IllegalArgumentException("Phone must be 10 digits");

            this.supplierName = name;
            this.supplierEmail = email;
            this.supplierPhone = phone;
        }

        public String getSupplierName() { return supplierName; }
        public String getSupplierEmail() { return supplierEmail; }
        public String getSupplierPhone() { return supplierPhone; }
    }

