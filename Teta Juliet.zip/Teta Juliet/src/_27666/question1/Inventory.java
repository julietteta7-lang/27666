package _27666.question1;
    public class Inventory extends Entity {
        private int totalItems;
        private double stockValue;

        public Inventory(int id, int totalItems, double stockValue) {
            super(id);

            if (totalItems < 0 || stockValue < 0)
                throw new IllegalArgumentException("Values must be >= 0");

            this.totalItems = totalItems;
            this.stockValue = stockValue;
        }

        public int getTotalItems() { return totalItems; }
        public double getStockValue() { return stockValue; }
    }

