package _27666.question1;
import java.util.Scanner;

    public class Main {
        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);
            String studentID = "(27666)";

            System.out.println("=== Stock Management System ===");

            // Warehouse
            System.out.print("Enter Warehouse Name: ");
            String wName = sc.nextLine();

            System.out.print("Enter Warehouse Location: ");
            String wLoc = sc.nextLine();

            System.out.print("Enter Warehouse Contact (10 digits): ");
            String wPhone = sc.nextLine();

            Warehouse warehouse = new Warehouse(1, wName, wLoc, wPhone);

            // Category
            System.out.print("Enter Category Name: ");
            String cName = sc.nextLine();

            System.out.print("Enter Category Code (>=3 chars): ");
            String cCode = sc.nextLine();

            Category category = new Category(2, cName, cCode);

            // Supplier
            System.out.print("Enter Supplier Name: ");
            String sName = sc.nextLine();

            System.out.print("Enter Supplier Email: ");
            String sEmail = sc.nextLine();

            System.out.print("Enter Supplier Phone (10 digits): ");
            String sPhone = sc.nextLine();

            Supplier supplier = new Supplier(3, sName, sEmail, sPhone);

            // Product
            System.out.print("Enter Product Name: ");
            String pName = sc.nextLine();

            System.out.print("Enter Unit Price (>0): ");
            double price = sc.nextDouble();

            System.out.print("Enter Stock Limit (>=0): ");
            int limit = sc.nextInt();

            Product product = new Product(4, pName, price, limit);

            // Stock Item
            System.out.print("Enter Quantity Available: ");
            int qty = sc.nextInt();

            System.out.print("Enter Reorder Level: ");
            int reorder = sc.nextInt();

            StockItem stock = new StockItem(5, qty, reorder);

            // Purchase
            System.out.print("Enter Purchased Quantity: ");
            int pQty = sc.nextInt();
            sc.nextLine();

            Purchase purchase = new Purchase(6, pQty, supplier.getSupplierName());

            // Sale
            System.out.print("Enter Sold Quantity: ");
            int sold = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter Customer Name: ");
            String cust = sc.nextLine();

            Sale sale = new Sale(7, sold, cust);

            // Inventory
            int totalItems = qty + pQty - sold;
            double stockValue = totalItems * product.getUnitPrice();

            Inventory inv = new Inventory(8, totalItems, stockValue);

            // Stock Report
            StockReport report = new StockReport(9, "Monthly Stock Summary");

            System.out.println(
                    report.generateReport(
                            inv.getTotalItems(),
                            inv.getStockValue(),
                            sale.getSoldQuantity(),
                            studentID
                    )
            );

            sc.close();
        }
    }

