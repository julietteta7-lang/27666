package _27666.question1;
import java.time.LocalDate;

    public class Sale extends Entity {
        private LocalDate saleDate;
        private int soldQuantity;
        private String customerName;

        public Sale(int id, int soldQuantity, String customerName) {
            super(id);

            if (soldQuantity <= 0)
                throw new IllegalArgumentException("Sold quantity must be > 0");

            this.soldQuantity = soldQuantity;
            this.customerName = customerName;
            this.saleDate = LocalDate.now();
        }

        public int getSoldQuantity() { return soldQuantity; }
        public String getCustomerName() { return customerName; }
        public LocalDate getSaleDate() { return saleDate; }
    }

