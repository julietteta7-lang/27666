package _27666.question1;
    public class StockItem extends Entity {
        private int quantityAvailable;
        private int reorderLevel;

        public StockItem(int id, int qty, int reorderLevel) {
            super(id);

            if (qty < 0 || reorderLevel < 0)
                throw new IllegalArgumentException("Values must be >= 0");

            this.quantityAvailable = qty;
            this.reorderLevel = reorderLevel;
        }

        public int getQuantityAvailable() { return quantityAvailable; }
        public int getReorderLevel() { return reorderLevel; }
    }

