package _27666.question1;
    public class Product extends Entity {
        private String productName;
        private double unitPrice;
        private int stockLimit;

        public Product(int id, String name, double price, int stockLimit) {
            super(id);

            if (price <= 0) throw new IllegalArgumentException("Price must be > 0");
            if (stockLimit < 0) throw new IllegalArgumentException("Stock limit must be >= 0");

            this.productName = name;
            this.unitPrice = price;
            this.stockLimit = stockLimit;
        }

        public String getProductName() { return productName; }
        public double getUnitPrice() { return unitPrice; }
        public int getStockLimit() { return stockLimit; }
    }

