package _27666.question2;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.Scanner;

    public class Main {

        // Helper method to print with Student ID
        public static void printWithID(String text, String id) {
            System.out.println(text + " " + id);
        }

        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);

            String studentID = "(27666)";

            System.out.println("=== Flight Booking System ===");

            System.out.print("Enter Airport Name: ");
            String airportName = sc.nextLine();

            System.out.print("Enter Airport Code (any 3 characters): ");
            String code = sc.nextLine();
            if (code.length() < 3) code = (code + "XXX").substring(0, 3);

            System.out.print("Enter Location: ");
            String location = sc.nextLine();

            Airport airport = new Airport(1, airportName, code.toUpperCase(), location);

            System.out.print("Enter Airline Name: ");
            String airlineName = sc.nextLine();

            System.out.print("Enter Airline Code (2-4 letters): ");
            String airlineCode = sc.nextLine();

            System.out.print("Enter Airline Email: ");
            String contactEmail = sc.nextLine();

            Airline airline = new Airline(1, airlineName, airlineCode, contactEmail);

            System.out.print("Enter Flight Number: ");
            String flightNumber = sc.nextLine();

            System.out.print("Enter Departure: ");
            String departure = sc.nextLine();

            System.out.print("Enter Destination: ");
            String destination = sc.nextLine();

            System.out.print("Enter Base Fare (>0): ");
            double baseFare = sc.nextDouble();
            sc.nextLine();

            String depCode = departure.length() >= 3 ? departure.substring(0, 3).toUpperCase() : "DEP";
            String destCode = destination.length() >= 3 ? destination.substring(0, 3).toUpperCase() : "DES";

            Airport depAirport = new Airport(2, departure + " Airport", depCode, departure);
            Airport destAirport = new Airport(3, destination + " Airport", destCode, destination);

            Flight flight = new Flight(1, flightNumber, depAirport, destAirport, baseFare);

            System.out.print("Enter Passenger Name: ");
            String passengerName = sc.nextLine();

            System.out.print("Enter Age: ");
            int age = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter Gender (Male/Female/Other): ");
            String gender = sc.nextLine();

            System.out.print("Enter Contact Info: ");
            String contact = sc.nextLine();

            Passenger passenger = new Passenger(1, passengerName, age, gender, contact);

            System.out.print("Enter Seat Number: ");
            String seatNumber = sc.nextLine();

            System.out.print("Enter Travel Class (Economy/Business/First): ");
            String travelClass = sc.nextLine();

            BookingRecord booking = new BookingRecord(1, LocalDate.now(), seatNumber, travelClass, flight, passenger);

            System.out.print("Enter Ticket Number: ");
            String ticketNumber = sc.nextLine();

            Ticket ticket = new Ticket(1, ticketNumber, booking);

            System.out.println("\n---- TICKET DETAILS ---- " + studentID);

            System.out.println("Ticket Number: " + ticket.getTicketNumber());
            System.out.println("Issue Date: " + ticket.getIssueDate());
            System.out.println("Passenger: " + passenger.getPassengerName());
            System.out.println("Flight: " + flight.getFlightNumber() + " from " +
                    depAirport.getAirportName() + " to " + destAirport.getAirportName());
            System.out.println("Airline: " + airline.getAirlineName());
            System.out.println("Seat: " + booking.getSeatNumber() + ", Class: " + booking.getTravelClass());
            System.out.println("Base Fare: $" + flight.getBaseFare());
            System.out.println("Total Fare (with taxes & discounts): $" + ticket.calculateFare());
            System.out.println("------------------------");


            sc.close();
        }
    }
