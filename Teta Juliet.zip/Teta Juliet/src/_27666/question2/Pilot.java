package _27666.question2;
 public class Pilot extends Entity {
        private String pilotName;
        private String licenseNumber;
        private int experienceYears;

        public Pilot(int id, String pilotName, String licenseNumber, int experienceYears) {
            super(id);
            this.pilotName = pilotName;
            setLicenseNumber(licenseNumber);
            setExperienceYears(experienceYears);
        }

        public void setLicenseNumber(String license) {
            if (license.isEmpty()) throw new IllegalArgumentException("License cannot be empty");
            this.licenseNumber = license;
        }

        public void setExperienceYears(int years) {
            if (years < 2) throw new IllegalArgumentException("Experience must be ≥ 2 years");
            this.experienceYears = years;
        }

        public String getPilotName() { return pilotName; }
        public String getLicenseNumber() { return licenseNumber; }
        public int getExperienceYears() { return experienceYears; }
    }

