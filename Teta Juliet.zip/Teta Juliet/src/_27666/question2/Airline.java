package _27666.question2;
    public class Airline extends Entity {
        private String airlineName;
        private String airlineCode;  // 2–4 letters
        private String contactEmail;

        public Airline(int id, String airlineName, String airlineCode, String contactEmail) {
            super(id);
            this.airlineName = airlineName;
            setAirlineCode(airlineCode);
            setContactEmail(contactEmail);
        }

        public void setAirlineCode(String code) {
            if (!code.matches("[A-Za-z]{2,4}"))
                throw new IllegalArgumentException("Code must be 2–4 letters");
            this.airlineCode = code;
        }

        public void setContactEmail(String email) {
            if (!email.matches("^[\\w-.]+@[\\w-]+\\.[a-zA-Z]{2,}$"))
                throw new IllegalArgumentException("Invalid email");
            this.contactEmail = email;
        }

        public String getAirlineName() { return airlineName; }
        public String getAirlineCode() { return airlineCode; }
        public String getContactEmail() { return contactEmail; }
    }


