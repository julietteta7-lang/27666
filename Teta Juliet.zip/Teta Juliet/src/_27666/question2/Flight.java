package _27666.question2;
 public class Flight extends Entity {
        private String flightNumber;
        private Airport departure;
        private Airport destination;
        private double baseFare;

        public Flight(int id, String flightNumber, Airport departure, Airport destination, double baseFare) {
            super(id);
            this.flightNumber = flightNumber;
            this.departure = departure;
            this.destination = destination;
            setBaseFare(baseFare);
        }

        public void setBaseFare(double baseFare) {
            if (baseFare <= 0) throw new IllegalArgumentException("Fare must be > 0");
            this.baseFare = baseFare;
        }

        public String getFlightNumber() { return flightNumber; }
        public Airport getDeparture() { return departure; }
        public Airport getDestination() { return destination; }
        public double getBaseFare() { return baseFare; }
    }
