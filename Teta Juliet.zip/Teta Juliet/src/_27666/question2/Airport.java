package _27666.question2;
    public class Airport extends Entity {
        private String airportName;
        private String code;  // 3 uppercase letters
        private String location;

        public Airport(int id, String airportName, String code, String location) {
            super(id);
            this.airportName = airportName;
            setCode(code);
            this.location = location;
        }

        public String getAirportName() { return airportName; }
        public void setAirportName(String airportName) { this.airportName = airportName; }

        public String getCode() { return code; }
        public void setCode(String code) {
            if (!code.matches("[A-Z]{3}"))
                throw new IllegalArgumentException("Code must be any letters");
            this.code = code;
        }

        public String getLocation() { return location; }
        public void setLocation(String location) { this.location = location; }
}
