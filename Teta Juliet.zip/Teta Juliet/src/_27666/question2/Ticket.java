package _27666.question2;
import java.time.LocalDate;

    public final class Ticket extends Entity {
        private String ticketNumber;
        private LocalDate issueDate;
        private BookingRecord booking;

        public Ticket(int id, String ticketNumber, BookingRecord booking) {
            super(id);
            this.ticketNumber = ticketNumber;
            this.issueDate = LocalDate.now();
            this.booking = booking;
        }

        public double calculateFare() {
            double baseFare = booking.getFlight().getBaseFare();
            double taxes = baseFare * 0.15; // Example tax 15%
            double discount = 0; // can customize per passenger
            return baseFare + taxes - discount;
        }

        public String getTicketNumber() { return ticketNumber; }
        public LocalDate getIssueDate() { return issueDate; }
        public BookingRecord getBooking() { return booking; }
    }

