package _27666.question2;
    public class CabinCrew extends Entity {
        private String crewName;
        private String role;
        private String shift;  // Day/Night

        public CabinCrew(int id, String crewName, String role, String shift) {
            super(id);
            this.crewName = crewName;
            setRole(role);
            setShift(shift);
        }

        public void setRole(String role) {
            if (role.isEmpty()) throw new IllegalArgumentException("Role cannot be empty");
            this.role = role;
        }

        public void setShift(String shift) {
            if (!shift.equals("Day") && !shift.equals("Night"))
                throw new IllegalArgumentException("Shift must be Day or Night");
            this.shift = shift;
        }

        public String getCrewName() { return crewName; }
        public String getRole() { return role; }
        public String getShift() { return shift; }
    }

