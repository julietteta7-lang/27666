package _27666.question2;
import java.time.LocalDate;

    public class BookingRecord extends Entity {
        private LocalDate bookingDate;
        private String seatNumber;
        private String travelClass;  // Economy/Business/First
        private Flight flight;
        private Passenger passenger;

        public BookingRecord(int id, LocalDate bookingDate, String seatNumber, String travelClass, Flight flight, Passenger passenger) {
            super(id);
            this.bookingDate = bookingDate;
            this.seatNumber = seatNumber;
            setTravelClass(travelClass);
            this.flight = flight;
            this.passenger = passenger;
        }

        public void setTravelClass(String travelClass) {
            if (!travelClass.equals("Economy") && !travelClass.equals("Business") && !travelClass.equals("First"))
                throw new IllegalArgumentException("Class must be Economy/Business/First");
            this.travelClass = travelClass;
        }

        public LocalDate getBookingDate() { return bookingDate; }
        public String getSeatNumber() { return seatNumber; }
        public String getTravelClass() { return travelClass; }
        public Flight getFlight() { return flight; }
        public Passenger getPassenger() { return passenger; }
    }

