package _27666.question2;
import java.time.LocalDate;

    public class Payment extends Entity {
        private LocalDate paymentDate;
        private String paymentMethod;
        private double amountPaid;

        public Payment(int id, LocalDate paymentDate, String paymentMethod, double amountPaid) {
            super(id);
            this.paymentDate = paymentDate;
            setPaymentMethod(paymentMethod);
            setAmountPaid(amountPaid);
        }

        public void setPaymentMethod(String method) {
            if (method.isEmpty()) throw new IllegalArgumentException("Method cannot be empty");
            this.paymentMethod = method;
        }

        public void setAmountPaid(double amount) {
            if (amount <= 0) throw new IllegalArgumentException("Amount must be > 0");
            this.amountPaid = amount;
        }

        public LocalDate getPaymentDate() { return paymentDate; }
        public String getPaymentMethod() { return paymentMethod; }
        public double getAmountPaid() { return amountPaid; }
    }


