package _27666.question2;
    public class Passenger extends Entity {
        private String passengerName;
        private int age;
        private String gender;
        private String contact;

        public Passenger(int id, String passengerName, int age, String gender, String contact) {
            super(id);
            this.passengerName = passengerName;
            setAge(age);
            setGender(gender);
            this.contact = contact;
        }

        public void setAge(int age) {
            if (age <= 0) throw new IllegalArgumentException("Age must be > 0");
            this.age = age;
        }

        public void setGender(String gender) {
            if (!gender.equalsIgnoreCase("Male") &&
                    !gender.equalsIgnoreCase("Female") &&
                    !gender.equalsIgnoreCase("Other"))
                throw new IllegalArgumentException("Invalid gender");
            this.gender = gender;
        }

        public String getPassengerName() { return passengerName; }
        public int getAge() { return age; }
        public String getGender() { return gender; }
        public String getContact() { return contact; }
    }

